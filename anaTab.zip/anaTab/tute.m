function tute

% tute: tutorial in the use of anaTab

	% Specify tasks to be performed
	switch 'cos'
		case 'cos' % plot cosine functions with differing amplitudes
			m.tasks = 'cos plot set'; % tasks
			%	m.plot.group = 'amp'; % grouping variable for axes
			m.line = 'amp'; % grouping variable for lines
			m.x = 'time'; m.y = 'fun'; % plotting variables
	end
	
	% Define handles for task functions in this file
	m.cos.fun = @doCos;

	% Run the tasks
	d = table(1); % dummy table
	anaTab(d, m); % run the analysis tasks

function [d, m] = doCos(d, m)

% Calculate cosine functions

	% Calculate
	t = linspace(0, 2 * pi, 65); % time (s)
	t = t(1: end - 1); % open-ended interval
	f = cos(t); % cosine function
	f2 = 2 * f; % different amplitude
	
	% Store
	d.time = t; % time
	d = repmat(d, [2, 1]); % make second row
	d.amp = [1; 2]; % amplitude
	d.fun = [f; f2]; % function
